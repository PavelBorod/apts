package task

import (
	"testing"

	check "gopkg.in/check.v1"
)

// Launch gocheck tests
func Test(t *testing.T) {
	check.TestingT(t)
}
