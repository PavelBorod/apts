// +build !go1.7

package http

import (
	"net/http"
)

func initTransport(transport *http.Transport) {

}
