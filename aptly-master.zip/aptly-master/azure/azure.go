// Package azure handles publishing to Azure Storage
package azure
