package aptly

// Version of aptly (filled in at link time)
var Version string

// EnableDebug triggers some debugging features
const EnableDebug = false
