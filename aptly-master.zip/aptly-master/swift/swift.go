// Package swift handles publishing to OpenStack Swift
package swift
