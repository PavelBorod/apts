// Package s3 handles publishing to Amazon S3
package s3
