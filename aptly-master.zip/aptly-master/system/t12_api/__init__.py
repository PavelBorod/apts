"""
Testing aptly REST API
"""
