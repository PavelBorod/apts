"""
Testing mirror management
"""
