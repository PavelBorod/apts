"""
Test aptly task run
"""
