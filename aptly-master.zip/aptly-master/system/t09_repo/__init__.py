"""
Testing local repo management
"""
