"""
Testing publishing snapshots
"""
