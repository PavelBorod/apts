"""
Testing snapshot management
"""
