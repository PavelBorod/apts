// Package goleveldb implements database interface via goleveldb
package goleveldb
