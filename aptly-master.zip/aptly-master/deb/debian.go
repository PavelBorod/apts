// Package deb implements Debian-specific repository handling
package deb
